ImpactMojo — Evaluation Essentials Kit
Free to adapt under CC BY-NC-ND 4.0
https://www.impactmojo.in/products.html

Contents:
 - ImpactMojo-ToR-Template.docx
 - ImpactMojo-Budget-Template.xlsx
 - ImpactMojo-Proposal-Scoring-Rubric.xlsx
 - ImpactMojo-MEL-Plan-Template.docx
 - ImpactMojo-Logframe-Template.xlsx
 - ImpactMojo-Commissioning-Workbook.docx
 - ImpactMojo-Intro-to-MEL-Deck.pptx